namespace Steve_0202
{
    public partial class Form1 : Form
    {
        string[] Kata = new string[5];
        public Form1()
        {
            InitializeComponent();
        }

        private void lbl_1_Click(object sender, EventArgs e)
        {

        }

        private void btn_play_Click(object sender, EventArgs e)
        {
            bool test = false;

            Kata[0] = tb_1.Text;
            Kata[1] = tb_2.Text;
            Kata[2] = tb_3.Text;
            Kata[3] = tb_4.Text;
            Kata[4] = tb_5.Text;

            bool SalahKata = false;
            bool SalahJumlah = false;
            bool SalahKembar = false;

            int check = 0;
            foreach (string kata in Kata)
            {
                Kata[check] = Kata[check].ToUpper();
                check++;
            }
            foreach (string kata in Kata)
            {
                foreach (char k in kata)
                {
                    if (!char.IsLetter(k))
                    {
                        SalahKata = true;
                        break;
                    }
                }
                if (SalahKata)
                {
                    MessageBox.Show("Salah\nKata Memiliki Simbol/Angka.");
                    break;
                }
            }
            foreach (string kata in Kata)
            {
                if (kata.Length != 5)
                {
                    SalahJumlah = true;
                }
                if (SalahJumlah)
                {
                    MessageBox.Show("Kata Memiliki Jumlah Salah.");
                    break;
                }
            }
            for (int i = 0; i < 5; i++)
            {
                for (int j = i + 1; j < 5; j++)
                {
                    if (i == j)
                    {
                        continue;
                    }
                    if (Kata[i] == Kata[j])
                    {
                        SalahKembar = true;
                        break;
                    }
                }
            }
            if (SalahKembar)
            {
                MessageBox.Show("Kata Ada Yang Kembar.");
            }
            if (SalahKembar || SalahKata || SalahJumlah)
            {
                MessageBox.Show("Tolong Diulang.");
            }
            else
            {
                Random random = new Random();
                string acak = Kata[random.Next(0, 5)];
                Wordle wordle = new Wordle(acak);
                wordle.Show();
            }
        }
    }
}
