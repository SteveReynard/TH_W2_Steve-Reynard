﻿namespace Steve_0202
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lbl_1 = new Label();
            lbl_2 = new Label();
            lbl_3 = new Label();
            lbl_4 = new Label();
            label5 = new Label();
            tb_1 = new TextBox();
            tb_2 = new TextBox();
            tb_3 = new TextBox();
            tb_4 = new TextBox();
            tb_5 = new TextBox();
            lbl_title = new Label();
            btn_play = new Button();
            SuspendLayout();
            // 
            // lbl_1
            // 
            lbl_1.AutoSize = true;
            lbl_1.Font = new Font("Lucida Calligraphy", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_1.Location = new Point(14, 64);
            lbl_1.Name = "lbl_1";
            lbl_1.Size = new Size(16, 20);
            lbl_1.TabIndex = 0;
            lbl_1.Text = "1";
            lbl_1.Click += lbl_1_Click;
            // 
            // lbl_2
            // 
            lbl_2.AutoSize = true;
            lbl_2.Font = new Font("Lucida Calligraphy", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_2.Location = new Point(12, 96);
            lbl_2.Name = "lbl_2";
            lbl_2.Size = new Size(19, 20);
            lbl_2.TabIndex = 1;
            lbl_2.Text = "2";
            // 
            // lbl_3
            // 
            lbl_3.AutoSize = true;
            lbl_3.Font = new Font("Lucida Calligraphy", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_3.Location = new Point(12, 129);
            lbl_3.Name = "lbl_3";
            lbl_3.Size = new Size(18, 20);
            lbl_3.TabIndex = 2;
            lbl_3.Text = "3";
            // 
            // lbl_4
            // 
            lbl_4.AutoSize = true;
            lbl_4.Font = new Font("Lucida Calligraphy", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_4.Location = new Point(12, 162);
            lbl_4.Name = "lbl_4";
            lbl_4.Size = new Size(20, 20);
            lbl_4.TabIndex = 3;
            lbl_4.Text = "4";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Lucida Calligraphy", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(12, 196);
            label5.Name = "label5";
            label5.Size = new Size(18, 20);
            label5.TabIndex = 4;
            label5.Text = "5";
            // 
            // tb_1
            // 
            tb_1.Location = new Point(50, 60);
            tb_1.Name = "tb_1";
            tb_1.Size = new Size(183, 27);
            tb_1.TabIndex = 5;
            // 
            // tb_2
            // 
            tb_2.Location = new Point(50, 93);
            tb_2.Name = "tb_2";
            tb_2.Size = new Size(183, 27);
            tb_2.TabIndex = 6;
            // 
            // tb_3
            // 
            tb_3.Location = new Point(50, 126);
            tb_3.Name = "tb_3";
            tb_3.Size = new Size(183, 27);
            tb_3.TabIndex = 7;
            // 
            // tb_4
            // 
            tb_4.Location = new Point(50, 159);
            tb_4.Name = "tb_4";
            tb_4.Size = new Size(183, 27);
            tb_4.TabIndex = 8;
            // 
            // tb_5
            // 
            tb_5.Location = new Point(50, 192);
            tb_5.Name = "tb_5";
            tb_5.Size = new Size(183, 27);
            tb_5.TabIndex = 9;
            // 
            // lbl_title
            // 
            lbl_title.AutoSize = true;
            lbl_title.Font = new Font("Lucida Calligraphy", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_title.Location = new Point(12, 20);
            lbl_title.Name = "lbl_title";
            lbl_title.Size = new Size(241, 27);
            lbl_title.TabIndex = 10;
            lbl_title.Text = "Welcome To Wordle";
            // 
            // btn_play
            // 
            btn_play.Font = new Font("Lucida Calligraphy", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_play.Location = new Point(12, 238);
            btn_play.Name = "btn_play";
            btn_play.Size = new Size(241, 29);
            btn_play.TabIndex = 11;
            btn_play.Text = "Play";
            btn_play.UseVisualStyleBackColor = true;
            btn_play.Click += btn_play_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(263, 283);
            Controls.Add(btn_play);
            Controls.Add(lbl_title);
            Controls.Add(tb_5);
            Controls.Add(tb_4);
            Controls.Add(tb_3);
            Controls.Add(tb_2);
            Controls.Add(tb_1);
            Controls.Add(label5);
            Controls.Add(lbl_4);
            Controls.Add(lbl_3);
            Controls.Add(lbl_2);
            Controls.Add(lbl_1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbl_1;
        private Label lbl_2;
        private Label lbl_3;
        private Label lbl_4;
        private Label label5;
        private TextBox tb_1;
        private TextBox tb_2;
        private TextBox tb_3;
        private TextBox tb_4;
        private TextBox tb_5;
        private Label lbl_title;
        private Button btn_play;
    }
}
