﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Steve_0202
{
    public partial class Wordle : Form
    {
        string Kata;
        int Check = 0;
        public Wordle(string acak)
        {
            InitializeComponent();
            lbl_jawaban.Text = acak;
            Kata = acak;
        }

        private void Wordle_Load(object sender, EventArgs e)
        {

        }

        private void btn_1_Click(object sender, EventArgs e)
        {
            int index = 1;
            foreach (char c in Kata)
            {
                if (index > 5)
                {
                    break;
                }
                if (c == 'Q')
                {
                    Controls[$"lbl_g_{index}"].Text = "Q";
                    Check++;
                }
                index++;
            }
            if (Check == 5)
            {
                MessageBox.Show("Menang!!");
            }
        }

        private void btn_2_Click(object sender, EventArgs e)
        {
            int index = 1;
            foreach (char c in Kata)
            {
                if (index > 5)
                {
                    break;
                }
                if (c == 'W')
                {
                    Controls[$"lbl_g_{index}"].Text = "W";
                    Check++;
                }
                index++;
            }
            if (Check == 5)
            {
                MessageBox.Show("Menang!!");
            }
        }

        private void btn_3_Click(object sender, EventArgs e)
        {
            int index = 1;
            foreach (char c in Kata)
            {
                if (index > 5)
                {
                    break;
                }
                if (c == 'E')
                {
                    Controls[$"lbl_g_{index}"].Text = "E";
                    Check++;
                }
                index++;
            }
            if (Check == 5)
            {
                MessageBox.Show("Menang!!");
            }
        }

        private void btn_4_Click(object sender, EventArgs e)
        {
            int index = 1;
            foreach (char c in Kata)
            {
                if (index > 5)
                {
                    break;
                }
                if (c == 'R')
                {
                    Controls[$"lbl_g_{index}"].Text = "R";
                    Check++;
                }
                index++;
            }
            if (Check == 5)
            {
                MessageBox.Show("Menang!!");
            }
        }

        private void btn_5_Click(object sender, EventArgs e)
        {
            int index = 1;
            foreach (char c in Kata)
            {
                if (index > 5)
                {
                    break;
                }
                if (c == 'T')
                {
                    Controls[$"lbl_g_{index}"].Text = "T";
                    Check++;
                }
                index++;
            }
            if (Check == 5)
            {
                MessageBox.Show("Menang!!");
            }
        }

        private void btn_6_Click(object sender, EventArgs e)
        {
            int index = 1;
            foreach (char c in Kata)
            {
                if (index > 5)
                {
                    break;
                }
                if (c == 'Y')
                {
                    Controls[$"lbl_g_{index}"].Text = "Y";
                    Check++;
                }
                index++;
            }
            if (Check == 5)
            {
                MessageBox.Show("Menang!!");
            }
        }

        private void btn_7_Click(object sender, EventArgs e)
        {
            int index = 1;
            foreach (char c in Kata)
            {
                if (index > 5)
                {
                    break;
                }
                if (c == 'U')
                {
                    Controls[$"lbl_g_{index}"].Text = "U";
                    Check++;
                }
                index++;
            }
            if (Check == 5)
            {
                MessageBox.Show("Menang!!");
            }
        }

        private void btn_8_Click(object sender, EventArgs e)
        {
            int index = 1;
            foreach (char c in Kata)
            {
                if (index > 5)
                {
                    break;
                }
                if (c == 'I')
                {
                    Controls[$"lbl_g_{index}"].Text = "I";
                    Check++;
                }
                index++;
            }
            if (Check == 5)
            {
                MessageBox.Show("Menang!!");
            }
        }

        private void btn_9_Click(object sender, EventArgs e)
        {
            int index = 1;
            foreach (char c in Kata)
            {
                if (index > 5)
                {
                    break;
                }
                if (c == 'O')
                {
                    Controls[$"lbl_g_{index}"].Text = "O";
                    Check++;
                }
                index++;
            }
            if (Check == 5)
            {
                MessageBox.Show("Menang!!");
            }
        }

        private void btn_10_Click(object sender, EventArgs e)
        {
            int index = 1;
            foreach (char c in Kata)
            {
                if (index > 5)
                {
                    break;
                }
                if (c == 'P')
                {
                    Controls[$"lbl_g_{index}"].Text = "P";
                    Check++;
                }
                index++;
            }
            if (Check == 5)
            {
                MessageBox.Show("Menang!!");
            }
        }

        private void btn_11_Click(object sender, EventArgs e)
        {
            int index = 1;
            foreach (char c in Kata)
            {
                if (index > 5)
                {
                    break;
                }
                if (c == 'A')
                {
                    Controls[$"lbl_g_{index}"].Text = "A";
                    Check++;
                }
                index++;
            }
            if (Check == 5)
            {
                MessageBox.Show("Menang!!");
            }
        }

        private void btn_12_Click(object sender, EventArgs e)
        {
            int index = 1;
            foreach (char c in Kata)
            {
                if (index > 5)
                {
                    break;
                }
                if (c == 'S')
                {
                    Controls[$"lbl_g_{index}"].Text = "S";
                    Check++;
                }
                index++;
            }
            if (Check == 5)
            {
                MessageBox.Show("Menang!!");
            }
        }

        private void btn_13_Click(object sender, EventArgs e)
        {
            int index = 1;
            foreach (char c in Kata)
            {
                if (index > 5)
                {
                    break;
                }
                if (c == 'D')
                {
                    Controls[$"lbl_g_{index}"].Text = "D";
                    Check++;
                }
                index++;
            }
            if (Check == 5)
            {
                MessageBox.Show("Menang!!");
            }
        }

        private void btn_14_Click(object sender, EventArgs e)
        {
            int index = 1;
            foreach (char c in Kata)
            {
                if (index > 5)
                {
                    break;
                }
                if (c == 'F')
                {
                    Controls[$"lbl_g_{index}"].Text = "F";
                    Check++;
                }
                index++;
            }
            if (Check == 5)
            {
                MessageBox.Show("Menang!!");
            }
        }

        private void btn_15_Click(object sender, EventArgs e)
        {
            int index = 1;
            foreach (char c in Kata)
            {
                if (index > 5)
                {
                    break;
                }
                if (c == 'G')
                {
                    Controls[$"lbl_g_{index}"].Text = "G";
                    Check++;
                }
                index++;
            }
            if (Check == 5)
            {
                MessageBox.Show("Menang!!");
            }
        }

        private void btn_16_Click(object sender, EventArgs e)
        {
            int index = 1;
            foreach (char c in Kata)
            {
                if (index > 5)
                {
                    break;
                }
                if (c == 'H')
                {
                    Controls[$"lbl_g_{index}"].Text = "H";
                    Check++;
                }
                index++;
            }
            if (Check == 5)
            {
                MessageBox.Show("Menang!!");
            }
        }

        private void btn_17_Click(object sender, EventArgs e)
        {
            int index = 1;
            foreach (char c in Kata)
            {
                if (index > 5)
                {
                    break;
                }
                if (c == 'J')
                {
                    Controls[$"lbl_g_{index}"].Text = "J";
                    Check++;
                }
                index++;
            }
            if (Check == 5)
            {
                MessageBox.Show("Menang!!");
            }
        }

        private void btn_18_Click(object sender, EventArgs e)
        {
            int index = 1;
            foreach (char c in Kata)
            {
                if (index > 5)
                {
                    break;
                }
                if (c == 'K')
                {
                    Controls[$"lbl_g_{index}"].Text = "K";
                    Check++;
                }
                index++;
            }
            if (Check == 5)
            {
                MessageBox.Show("Menang!!");
            }
        }

        private void btn_19_Click(object sender, EventArgs e)
        {
            int index = 1;
            foreach (char c in Kata)
            {
                if (index > 5)
                {
                    break;
                }
                if (c == 'L')
                {
                    Controls[$"lbl_g_{index}"].Text = "L";
                    Check++;
                }
                index++;
            }
            if (Check == 5)
            {
                MessageBox.Show("Menang!!");
            }
        }

        private void btn_20_Click(object sender, EventArgs e)
        {
            int index = 1;
            foreach (char c in Kata)
            {
                if (index > 5)
                {
                    break;
                }
                if (c == 'Z')
                {
                    Controls[$"lbl_g_{index}"].Text = "Z";
                    Check++;
                }
                index++;
            }
            if (Check == 5)
            {
                MessageBox.Show("Menang!!");
            }
        }

        private void btn_21_Click(object sender, EventArgs e)
        {
            int index = 1;
            foreach (char c in Kata)
            {
                if (index > 5)
                {
                    break;
                }
                if (c == 'X')
                {
                    Controls[$"lbl_g_{index}"].Text = "X";
                    Check++;
                }
                index++;
            }
            if (Check == 5)
            {
                MessageBox.Show("Menang!!");
            }
        }

        private void btn_22_Click(object sender, EventArgs e)
        {
            int index = 1;
            foreach (char c in Kata)
            {
                if (index > 5)
                {
                    break;
                }
                if (c == 'C')
                {
                    Controls[$"lbl_g_{index}"].Text = "C";
                    Check++;
                }
                index++;
            }
            if (Check == 5)
            {
                MessageBox.Show("Menang!!");
            }
        }

        private void btn_23_Click(object sender, EventArgs e)
        {
            int index = 1;
            foreach (char c in Kata)
            {
                if (index > 5)
                {
                    break;
                }
                if (c == 'V')
                {
                    Controls[$"lbl_g_{index}"].Text = "V";
                    Check++;
                }
                index++;
            }
            if (Check == 5)
            {
                MessageBox.Show("Menang!!");
            }
        }

        private void btn_24_Click(object sender, EventArgs e)
        {
            int index = 1;
            foreach (char c in Kata)
            {
                if (index > 5)
                {
                    break;
                }
                if (c == 'B')
                {
                    Controls[$"lbl_g_{index}"].Text = "B";
                    Check++;
                }
                index++;
            }
            if (Check == 5)
            {
                MessageBox.Show("Menang!!");
            }
        }

        private void btn_25_Click(object sender, EventArgs e)
        {
            int index = 1;
            foreach (char c in Kata)
            {
                if (index > 5)
                {
                    break;
                }
                if (c == 'N')
                {
                    Controls[$"lbl_g_{index}"].Text = "N";
                    Check++;
                }
                index++;
            }
            if (Check == 5)
            {
                MessageBox.Show("Menang!!");
            }
        }

        private void btn_26_Click(object sender, EventArgs e)
        {
            int index = 1;
            foreach (char c in Kata)
            {
                if (index > 5)
                {
                    break;
                }
                if (c == 'M')
                {
                    Controls[$"lbl_g_{index}"].Text = "M";
                    Check++;
                }
                index++;
            }
            if (Check == 5)
            {
                MessageBox.Show("Menang!!");
            }
        }
    }
}
