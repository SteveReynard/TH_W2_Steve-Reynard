﻿namespace Steve_0202
{
    partial class Wordle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lbl_title = new Label();
            lbl_g_1 = new Label();
            lbl_g_2 = new Label();
            lbl_g_3 = new Label();
            lbl_g_4 = new Label();
            lbl_g_5 = new Label();
            btn_1 = new Button();
            btn_2 = new Button();
            btn_3 = new Button();
            btn_4 = new Button();
            btn_5 = new Button();
            btn_6 = new Button();
            btn_7 = new Button();
            btn_8 = new Button();
            btn_9 = new Button();
            btn_10 = new Button();
            btn_19 = new Button();
            btn_18 = new Button();
            btn_17 = new Button();
            btn_16 = new Button();
            btn_15 = new Button();
            btn_14 = new Button();
            btn_13 = new Button();
            btn_12 = new Button();
            btn_11 = new Button();
            btn_26 = new Button();
            btn_25 = new Button();
            btn_24 = new Button();
            btn_23 = new Button();
            btn_22 = new Button();
            btn_21 = new Button();
            btn_20 = new Button();
            lbl_jawaban = new Label();
            SuspendLayout();
            // 
            // lbl_title
            // 
            lbl_title.AutoSize = true;
            lbl_title.Font = new Font("Lucida Calligraphy", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_title.Location = new Point(164, 9);
            lbl_title.Name = "lbl_title";
            lbl_title.Size = new Size(139, 36);
            lbl_title.TabIndex = 0;
            lbl_title.Text = " Wordle";
            // 
            // lbl_g_1
            // 
            lbl_g_1.AutoSize = true;
            lbl_g_1.Font = new Font("Lucida Calligraphy", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_g_1.Location = new Point(164, 65);
            lbl_g_1.Name = "lbl_g_1";
            lbl_g_1.Size = new Size(26, 29);
            lbl_g_1.TabIndex = 1;
            lbl_g_1.Text = "_";
            // 
            // lbl_g_2
            // 
            lbl_g_2.AutoSize = true;
            lbl_g_2.Font = new Font("Lucida Calligraphy", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_g_2.Location = new Point(196, 65);
            lbl_g_2.Name = "lbl_g_2";
            lbl_g_2.Size = new Size(26, 29);
            lbl_g_2.TabIndex = 2;
            lbl_g_2.Text = "_";
            // 
            // lbl_g_3
            // 
            lbl_g_3.AutoSize = true;
            lbl_g_3.Font = new Font("Lucida Calligraphy", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_g_3.Location = new Point(228, 65);
            lbl_g_3.Name = "lbl_g_3";
            lbl_g_3.Size = new Size(26, 29);
            lbl_g_3.TabIndex = 3;
            lbl_g_3.Text = "_";
            // 
            // lbl_g_4
            // 
            lbl_g_4.AutoSize = true;
            lbl_g_4.Font = new Font("Lucida Calligraphy", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_g_4.Location = new Point(260, 65);
            lbl_g_4.Name = "lbl_g_4";
            lbl_g_4.Size = new Size(26, 29);
            lbl_g_4.TabIndex = 4;
            lbl_g_4.Text = "_";
            // 
            // lbl_g_5
            // 
            lbl_g_5.AutoSize = true;
            lbl_g_5.Font = new Font("Lucida Calligraphy", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_g_5.Location = new Point(292, 65);
            lbl_g_5.Name = "lbl_g_5";
            lbl_g_5.Size = new Size(26, 29);
            lbl_g_5.TabIndex = 5;
            lbl_g_5.Text = "_";
            // 
            // btn_1
            // 
            btn_1.Location = new Point(12, 106);
            btn_1.Name = "btn_1";
            btn_1.Size = new Size(40, 40);
            btn_1.TabIndex = 6;
            btn_1.Text = "Q";
            btn_1.UseVisualStyleBackColor = true;
            btn_1.Click += btn_1_Click;
            // 
            // btn_2
            // 
            btn_2.Location = new Point(58, 106);
            btn_2.Name = "btn_2";
            btn_2.Size = new Size(40, 40);
            btn_2.TabIndex = 7;
            btn_2.Text = "W";
            btn_2.UseVisualStyleBackColor = true;
            btn_2.Click += btn_2_Click;
            // 
            // btn_3
            // 
            btn_3.Location = new Point(104, 106);
            btn_3.Name = "btn_3";
            btn_3.Size = new Size(40, 40);
            btn_3.TabIndex = 8;
            btn_3.Text = "E";
            btn_3.UseVisualStyleBackColor = true;
            btn_3.Click += btn_3_Click;
            // 
            // btn_4
            // 
            btn_4.Location = new Point(150, 106);
            btn_4.Name = "btn_4";
            btn_4.Size = new Size(40, 40);
            btn_4.TabIndex = 9;
            btn_4.Text = "R";
            btn_4.UseVisualStyleBackColor = true;
            btn_4.Click += btn_4_Click;
            // 
            // btn_5
            // 
            btn_5.Location = new Point(196, 106);
            btn_5.Name = "btn_5";
            btn_5.Size = new Size(40, 40);
            btn_5.TabIndex = 10;
            btn_5.Text = "T";
            btn_5.UseVisualStyleBackColor = true;
            btn_5.Click += btn_5_Click;
            // 
            // btn_6
            // 
            btn_6.Location = new Point(242, 106);
            btn_6.Name = "btn_6";
            btn_6.Size = new Size(40, 40);
            btn_6.TabIndex = 11;
            btn_6.Text = "Y";
            btn_6.UseVisualStyleBackColor = true;
            btn_6.Click += btn_6_Click;
            // 
            // btn_7
            // 
            btn_7.Location = new Point(288, 106);
            btn_7.Name = "btn_7";
            btn_7.Size = new Size(40, 40);
            btn_7.TabIndex = 12;
            btn_7.Text = "U";
            btn_7.UseVisualStyleBackColor = true;
            btn_7.Click += btn_7_Click;
            // 
            // btn_8
            // 
            btn_8.Location = new Point(334, 106);
            btn_8.Name = "btn_8";
            btn_8.Size = new Size(40, 40);
            btn_8.TabIndex = 13;
            btn_8.Text = "I";
            btn_8.UseVisualStyleBackColor = true;
            btn_8.Click += btn_8_Click;
            // 
            // btn_9
            // 
            btn_9.Location = new Point(380, 106);
            btn_9.Name = "btn_9";
            btn_9.Size = new Size(40, 40);
            btn_9.TabIndex = 14;
            btn_9.Text = "O";
            btn_9.UseVisualStyleBackColor = true;
            btn_9.Click += btn_9_Click;
            // 
            // btn_10
            // 
            btn_10.Location = new Point(426, 106);
            btn_10.Name = "btn_10";
            btn_10.Size = new Size(40, 40);
            btn_10.TabIndex = 15;
            btn_10.Text = "P";
            btn_10.UseVisualStyleBackColor = true;
            btn_10.Click += btn_10_Click;
            // 
            // btn_19
            // 
            btn_19.Location = new Point(401, 152);
            btn_19.Name = "btn_19";
            btn_19.Size = new Size(40, 40);
            btn_19.TabIndex = 24;
            btn_19.Text = "L";
            btn_19.UseVisualStyleBackColor = true;
            btn_19.Click += btn_19_Click;
            // 
            // btn_18
            // 
            btn_18.Location = new Point(355, 152);
            btn_18.Name = "btn_18";
            btn_18.Size = new Size(40, 40);
            btn_18.TabIndex = 23;
            btn_18.Text = "K";
            btn_18.UseVisualStyleBackColor = true;
            btn_18.Click += btn_18_Click;
            // 
            // btn_17
            // 
            btn_17.Location = new Point(309, 152);
            btn_17.Name = "btn_17";
            btn_17.Size = new Size(40, 40);
            btn_17.TabIndex = 22;
            btn_17.Text = "J";
            btn_17.UseVisualStyleBackColor = true;
            btn_17.Click += btn_17_Click;
            // 
            // btn_16
            // 
            btn_16.Location = new Point(263, 152);
            btn_16.Name = "btn_16";
            btn_16.Size = new Size(40, 40);
            btn_16.TabIndex = 21;
            btn_16.Text = "H";
            btn_16.UseVisualStyleBackColor = true;
            btn_16.Click += btn_16_Click;
            // 
            // btn_15
            // 
            btn_15.Location = new Point(217, 152);
            btn_15.Name = "btn_15";
            btn_15.Size = new Size(40, 40);
            btn_15.TabIndex = 20;
            btn_15.Text = "G";
            btn_15.UseVisualStyleBackColor = true;
            btn_15.Click += btn_15_Click;
            // 
            // btn_14
            // 
            btn_14.Location = new Point(171, 152);
            btn_14.Name = "btn_14";
            btn_14.Size = new Size(40, 40);
            btn_14.TabIndex = 19;
            btn_14.Text = "F";
            btn_14.UseVisualStyleBackColor = true;
            btn_14.Click += btn_14_Click;
            // 
            // btn_13
            // 
            btn_13.Location = new Point(125, 152);
            btn_13.Name = "btn_13";
            btn_13.Size = new Size(40, 40);
            btn_13.TabIndex = 18;
            btn_13.Text = "D";
            btn_13.UseVisualStyleBackColor = true;
            btn_13.Click += btn_13_Click;
            // 
            // btn_12
            // 
            btn_12.Location = new Point(79, 152);
            btn_12.Name = "btn_12";
            btn_12.Size = new Size(40, 40);
            btn_12.TabIndex = 17;
            btn_12.Text = "S";
            btn_12.UseVisualStyleBackColor = true;
            btn_12.Click += btn_12_Click;
            // 
            // btn_11
            // 
            btn_11.Location = new Point(33, 152);
            btn_11.Name = "btn_11";
            btn_11.Size = new Size(40, 40);
            btn_11.TabIndex = 16;
            btn_11.Text = "A";
            btn_11.UseVisualStyleBackColor = true;
            btn_11.Click += btn_11_Click;
            // 
            // btn_26
            // 
            btn_26.Location = new Point(355, 198);
            btn_26.Name = "btn_26";
            btn_26.Size = new Size(40, 40);
            btn_26.TabIndex = 31;
            btn_26.Text = "M";
            btn_26.UseVisualStyleBackColor = true;
            btn_26.Click += btn_26_Click;
            // 
            // btn_25
            // 
            btn_25.Location = new Point(309, 198);
            btn_25.Name = "btn_25";
            btn_25.Size = new Size(40, 40);
            btn_25.TabIndex = 30;
            btn_25.Text = "N";
            btn_25.UseVisualStyleBackColor = true;
            btn_25.Click += btn_25_Click;
            // 
            // btn_24
            // 
            btn_24.Location = new Point(263, 198);
            btn_24.Name = "btn_24";
            btn_24.Size = new Size(40, 40);
            btn_24.TabIndex = 29;
            btn_24.Text = "B";
            btn_24.UseVisualStyleBackColor = true;
            btn_24.Click += btn_24_Click;
            // 
            // btn_23
            // 
            btn_23.Location = new Point(217, 198);
            btn_23.Name = "btn_23";
            btn_23.Size = new Size(40, 40);
            btn_23.TabIndex = 28;
            btn_23.Text = "V";
            btn_23.UseVisualStyleBackColor = true;
            btn_23.Click += btn_23_Click;
            // 
            // btn_22
            // 
            btn_22.Location = new Point(171, 198);
            btn_22.Name = "btn_22";
            btn_22.Size = new Size(40, 40);
            btn_22.TabIndex = 27;
            btn_22.Text = "C";
            btn_22.UseVisualStyleBackColor = true;
            btn_22.Click += btn_22_Click;
            // 
            // btn_21
            // 
            btn_21.Location = new Point(125, 198);
            btn_21.Name = "btn_21";
            btn_21.Size = new Size(40, 40);
            btn_21.TabIndex = 26;
            btn_21.Text = "X";
            btn_21.UseVisualStyleBackColor = true;
            btn_21.Click += btn_21_Click;
            // 
            // btn_20
            // 
            btn_20.Location = new Point(79, 198);
            btn_20.Name = "btn_20";
            btn_20.Size = new Size(40, 40);
            btn_20.TabIndex = 25;
            btn_20.Text = "Z";
            btn_20.UseVisualStyleBackColor = true;
            btn_20.Click += btn_20_Click;
            // 
            // lbl_jawaban
            // 
            lbl_jawaban.AutoSize = true;
            lbl_jawaban.Font = new Font("Lucida Calligraphy", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_jawaban.Location = new Point(355, 9);
            lbl_jawaban.Name = "lbl_jawaban";
            lbl_jawaban.Size = new Size(0, 27);
            lbl_jawaban.TabIndex = 32;
            // 
            // Wordle
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(477, 251);
            Controls.Add(lbl_jawaban);
            Controls.Add(btn_26);
            Controls.Add(btn_25);
            Controls.Add(btn_24);
            Controls.Add(btn_23);
            Controls.Add(btn_22);
            Controls.Add(btn_21);
            Controls.Add(btn_20);
            Controls.Add(btn_19);
            Controls.Add(btn_18);
            Controls.Add(btn_17);
            Controls.Add(btn_16);
            Controls.Add(btn_15);
            Controls.Add(btn_14);
            Controls.Add(btn_13);
            Controls.Add(btn_12);
            Controls.Add(btn_11);
            Controls.Add(btn_10);
            Controls.Add(btn_9);
            Controls.Add(btn_8);
            Controls.Add(btn_7);
            Controls.Add(btn_6);
            Controls.Add(btn_5);
            Controls.Add(btn_4);
            Controls.Add(btn_3);
            Controls.Add(btn_2);
            Controls.Add(btn_1);
            Controls.Add(lbl_g_5);
            Controls.Add(lbl_g_4);
            Controls.Add(lbl_g_3);
            Controls.Add(lbl_g_2);
            Controls.Add(lbl_g_1);
            Controls.Add(lbl_title);
            Name = "Wordle";
            Text = "Wordle";
            Load += Wordle_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbl_title;
        private Label lbl_g_1;
        private Label lbl_g_2;
        private Label lbl_g_3;
        private Label lbl_g_4;
        private Label lbl_g_5;
        private Button btn_1;
        private Button btn_2;
        private Button btn_3;
        private Button btn_4;
        private Button btn_5;
        private Button btn_6;
        private Button btn_7;
        private Button btn_8;
        private Button btn_9;
        private Button btn_10;
        private Button btn_19;
        private Button btn_18;
        private Button btn_17;
        private Button btn_16;
        private Button btn_15;
        private Button btn_14;
        private Button btn_13;
        private Button btn_12;
        private Button btn_11;
        private Button btn_26;
        private Button btn_25;
        private Button btn_24;
        private Button btn_23;
        private Button btn_22;
        private Button btn_21;
        private Button btn_20;
        private Label lbl_jawaban;
    }
}